<style>
	/* Accessible for screen readers but hidden from view */
	.fa-hidden { position:absolute; left:-10000px; top:auto; width:1px; height:1px; overflow:hidden; }
	.rtl .fa-hidden { left:10000px; }
	.fa-showtext { margin-right: 5px; }
</style>